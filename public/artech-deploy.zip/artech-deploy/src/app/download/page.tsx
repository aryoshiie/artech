// Halaman download source code Artech — sementara untuk user deploy ke Vercel
// Akses di /download
'use client';
import { useState } from "react";
import { Download, FileArchive, CheckCircle2, Copy, ExternalLink } from "lucide-react";

export default function DownloadPage() {
  const [copied, setCopied] = useState(false);

  function copyUrl() {
    navigator.clipboard.writeText(window.location.origin + "/artech-deploy.zip");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div style={{
      minHeight: "100vh",
      background: "radial-gradient(ellipse at top, #1d1740 0%, #05060d 60%)",
      color: "#eae8f5",
      fontFamily: "Manrope, sans-serif",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 20,
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Unbounded:wght@400;600;800&family=JetBrains+Mono:wght@400;500&display=swap');
        .font-display{ font-family:'Unbounded', sans-serif; }
        .font-mono{ font-family:'JetBrains Mono', monospace; }
        @keyframes pulse-glow{ 0%,100%{ box-shadow: 0 0 2vmin rgba(94,234,212,0.3); } 50%{ box-shadow: 0 0 4vmin rgba(94,234,212,0.6); } }
      `}</style>
      <div style={{
        maxWidth: 580,
        width: "100%",
        background: "linear-gradient(180deg, rgba(255,255,255,0.045), rgba(255,255,255,0.015))",
        border: "1px solid rgba(255,255,255,0.09)",
        borderRadius: 18,
        padding: 32,
        backdropFilter: "blur(16px)",
        animation: "pulse-glow 3s ease-in-out infinite",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
          <div style={{
            width: 48, height: 48, borderRadius: 12,
            background: "linear-gradient(135deg, #5eead4, #3f7fd1)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <FileArchive size={24} color="#05060d" />
          </div>
          <div>
            <h1 className="font-display" style={{ fontSize: 24, margin: 0 }}>ARTECH Source Code</h1>
            <p className="font-mono" style={{ fontSize: 11, color: "#8683a1", margin: "4px 0 0" }}>
              84 file • 116 KB • ZIP archive
            </p>
          </div>
        </div>

        <p className="font-mono" style={{ fontSize: 13, color: "#eae8f5", lineHeight: 1.6, marginBottom: 20 }}>
          Klik tombol di bawah untuk download source code lengkap webapp Artech.
          Setelah download, extract lalu upload ke Vercel.
        </p>

        <a
          href="/artech-deploy.zip"
          download="artech-deploy.zip"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            width: "100%",
            padding: "16px 20px",
            borderRadius: 12,
            background: "linear-gradient(135deg, #5eead4, #3f7fd1)",
            color: "#05060d",
            textDecoration: "none",
            fontWeight: 700,
            fontSize: 15,
            marginBottom: 16,
            border: "none",
            cursor: "pointer",
            fontFamily: "Unbounded, sans-serif",
            transition: "transform .2s ease, filter .2s ease",
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = "scale(1.02)"; e.currentTarget.style.filter = "brightness(1.1)"; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.filter = "brightness(1)"; }}
        >
          <Download size={20} strokeWidth={2.5} />
          DOWNLOAD artech-deploy.zip
        </a>

        <div style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 10,
          padding: "10px 12px",
          marginBottom: 20,
        }}>
          <code className="font-mono" style={{ flex: 1, fontSize: 11, color: "#5eead4", wordBreak: "break-all" }}>
            {typeof window !== "undefined" ? window.location.origin + "/artech-deploy.zip" : "/artech-deploy.zip"}
          </code>
          <button
            onClick={copyUrl}
            style={{
              background: "rgba(94,234,212,0.1)",
              border: "1px solid rgba(94,234,212,0.3)",
              borderRadius: 6,
              padding: "6px 8px",
              cursor: "pointer",
              color: "#5eead4",
              display: "flex",
            }}
            aria-label="Copy URL"
          >
            {copied ? <CheckCircle2 size={14} /> : <Copy size={14} />}
          </button>
        </div>

        <div style={{
          background: "rgba(94,234,212,0.05)",
          border: "1px solid rgba(94,234,212,0.15)",
          borderRadius: 10,
          padding: 14,
        }}>
          <p className="font-display" style={{ fontSize: 12, color: "#5eead4", margin: "0 0 8px", letterSpacing: ".05em" }}>
            📋 LANGKAH DEPLOY KE VERCEL
          </p>
          <ol className="font-mono" style={{ fontSize: 11, color: "#8683a1", lineHeight: 1.8, margin: 0, paddingLeft: 18 }}>
            <li>Download zip di atas</li>
            <li>Extract di komputer Anda</li>
            <li>Buka <a href="https://vercel.com/new" target="_blank" rel="noopener" style={{ color: "#5eead4" }}>vercel.com/new <ExternalLink size={10} style={{ display: "inline" }} /></a></li>
            <li>Drag & drop folder hasil extract</li>
            <li>Set Environment Variables (lihat README.md di dalam zip)</li>
            <li>Klik <b style={{ color: "#eae8f5" }}>Deploy</b></li>
          </ol>
        </div>

        <p className="font-mono" style={{ fontSize: 10, color: "#8683a1", textAlign: "center", marginTop: 16 }}>
          Setelah deploy, jangan lupa reset password Supabase (karena terekspos di chat)
        </p>

        <div style={{ textAlign: "center", marginTop: 16 }}>
          <a href="/" style={{ color: "#8683a1", fontSize: 11, textDecoration: "none", fontFamily: "JetBrains Mono, monospace" }}>
            ← Kembali ke Galaxy
          </a>
        </div>
      </div>
    </div>
  );
}
