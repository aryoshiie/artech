// src/app/api/n8n/test/route.ts
// Test koneksi ke n8n webhook.
// Body: { webhookUrl: string }
// Return: { ok: boolean, error?: string }

import { NextRequest, NextResponse } from "next/server";
import { testN8nConnection } from "@/lib/n8n";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { webhookUrl } = body as { webhookUrl?: string };

    if (!webhookUrl) {
      return NextResponse.json(
        { error: "webhookUrl wajib diisi" },
        { status: 400 }
      );
    }

    try {
      const ok = await testN8nConnection(webhookUrl);
      if (ok) {
        return NextResponse.json({ ok: true });
      }
      return NextResponse.json(
        { ok: false, error: "n8n merespons non-2xx atau gagal" },
        { status: 200 }
      );
    } catch (err: any) {
      return NextResponse.json(
        { ok: false, error: err?.message || "Gagal menghubungi n8n" },
        { status: 200 }
      );
    }
  } catch (err: any) {
    console.error("[API POST /n8n/test]", err);
    return NextResponse.json(
      { error: err?.message || "Request tidak valid" },
      { status: 500 }
    );
  }
}
