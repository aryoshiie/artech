# ARTECH · Multi-Agent Orchestrator

Webapp pusat kendali multi-agent dengan visualisasi tata surya. Terhubung ke workflow n8n via webhook.

## 🚀 Deploy ke Vercel

### Langkah 1: Upload Source Code
1. Download zip ini → extract di komputer
2. Buka https://vercel.com/new
3. Drag & drop folder hasil extract (atau push ke GitHub lalu import repo)

### Langkah 2: Set Environment Variables (WAJIB)
Di Vercel → Settings → Environment Variables, tambah:

```
DATABASE_URL=postgresql://postgres.bhkntsmylvngaawjzvnq:PASSWORD@aws-0-ap-northeast-1.pooler.supabase.com:6543/postgres?pgbouncer=true&connection_limit=1
DIRECT_URL=postgresql://postgres.bhkntsmylvngaawjzvnq:PASSWORD@aws-0-ap-northeast-1.pooler.supabase.com:5432/postgres
SUPABASE_URL=https://bhkntsmylvngaawjzvnq.supabase.co
SUPABASE_SERVICE_ROLE_KEY=sb_secret_xxxxx
N8N_BASE_URL=https://artha.loophole.site
N8N_ORCHESTRATOR_WEBHOOK_URL=https://artha.loophole.site/webhook/orchestrator
NEXT_PUBLIC_APP_NAME=ARTECH
NEXT_PUBLIC_SUPABASE_URL=https://bhkntsmylvngaawjzvnq.supabase.co
```

**Penting:** Ganti PASSWORD dengan database password Supabase Anda.

### Langkah 3: Deploy
Klik Deploy. Tunggu 2-3 menit. postinstall script akan otomatis jalankan prisma generate.

### Langkah 4: Setup Database (SEKALI SAJA)
Setelah deploy, database schema perlu di-push. Dari komputer lokal:

```bash
cd artech-deploy
cp .env.example .env
# Edit .env, isi PASSWORD Anda
bun install   # atau npm install
bun run db:push
bun run db:seed
```

Atau via Vercel CLI:
```bash
npm i -g vercel
vercel login
vercel link
vercel env pull .env.local
npx prisma db push
npx tsx prisma/seed.ts
```

### Langkah 5: Setup Owner Account
Buka URL Vercel Anda (mis. https://artech.vercel.app):
1. Akan otomatis redirect ke /setup
2. Buat username + password owner (password min 8 karakter)
3. Setelah setup, redirect ke /login
4. Login dengan username + password
5. Optional: Daftarkan Passkey (Touch ID / Face ID / Security Key) untuk login tanpa password

### Langkah 6: Setup Supabase Storage Bucket (untuk file upload)
1. Supabase Dashboard → Storage → New bucket
2. Name: artech-uploads, Public: No, Size limit: 50MB
3. Klik Create bucket

## 🔐 Sistem Login & Keamanan

### Login Methods
- Password — username + password (min 8 char)
- Passkey (WebAuthn) — Touch ID / Face ID / Security Key (tanpa password)

### Akses Protection
- Middleware melindungi semua route kecuali /login, /setup, /api/auth/*
- Setiap upaya login (sukses/gagal) dicatat di tabel AccessLog
- Login failed otomatis kirim notifikasi ke owner via webhook (kalau ownerNotifyWebhook di-set)
- Session cookie httpOnly, secure, 30 hari expiry

### Setup Notifikasi Owner (opsional)
Set ownerNotifyWebhook di Settings (via API PATCH /api/settings):
```json
{ "ownerNotifyWebhook": "https://artha.loophole.site/webhook/notify-owner" }
```
Setiap login_failed akan POST ke URL ini dengan payload:
```json
{
  "type": "security_alert",
  "event": "login_failed",
  "timestamp": "...",
  "ipAddress": "...",
  "userAgent": "...",
  "reason": "Invalid credentials",
  "username": "..."
}
```

### Lihat Access Logs
GET /api/auth/logs?limit=50 (perlu login)
Filter: ?event=login_failed untuk lihat hanya yang gagal.

## 🛠️ Development Lokal

```bash
bun install
cp .env.example .env  # edit dengan kredensial Anda
bun run db:push
bun run db:seed
bun run dev
```

Buka http://localhost:3000 → akan redirect ke /setup (kalau belum ada user) atau /login.

## 📦 Halaman Penting

| Route | Fungsi |
|---|---|
| / | Galaxy dashboard (perlu login) |
| /login | Login dengan password atau Passkey |
| /setup | Setup owner pertama (sekali saja) |
| /download | Download source code zip |
| /debug | Diagnostic: cek DB, env vars, koneksi |

## 🏗️ Arsitektur

```
Webapp (Next.js 16)
├── src/middleware.ts            ← Auth protection (redirect ke /login)
├── src/app/
│   ├── page.tsx                 ← UI galaxy + holo drawer + voice settings
│   ├── login/page.tsx           ← Login page (password + Passkey)
│   ├── setup/page.tsx           ← Setup owner pertama
│   ├── download/page.tsx        ← Halaman download source
│   ├── debug/page.tsx           ← Diagnostic page
│   └── api/
│       ├── agents/              ← CRUD agent + tools
│       ├── chat/                ← Routing Lapis 1 + kirim ke n8n
│       ├── sessions/            ← Session management
│       ├── settings/            ← Global settings
│       ├── auth/                ← Login, setup, passkey, access logs
│       ├── debug/               ← Diagnostic API
│       └── ...
├── src/lib/
│   ├── db.ts                    ← Prisma client
│   ├── n8n.ts                   ← Webhook client
│   ├── routing.ts               ← Routing Lapis 1
│   ├── supabase-storage.ts      ← File upload
│   ├── auth.ts                  ← Session + password + access log
│   └── webauthn.ts              ← WebAuthn helpers
└── prisma/
    ├── schema.prisma            ← Model: Agent, Tool, Message, Session, User, Passkey, AuthSession, AccessLog, Settings
    └── seed.ts                  ← 9 agent (Inti Galaksi + 8 planet) + 17 tools
```

## 🎨 Fitur

- 🔐 Login dengan password atau Passkey (WebAuthn)
- 🛡️ Akses protection + access logging + owner notification
- ✨ Visualisasi tata surya (9 agent sebagai planet mengorbit)
- 💬 Chat hologram di tengah (klik planet → toggle chat muncul)
- 🎙️ Voice per-agent (gender, pitch, rate, voice selection)
- 📝 Edit agent via sidebar (klik icon pencil)
- 🔌 Webhook URL otomatis per agent (untuk disambung ke n8n)
- 🗂️ File upload via Supabase Storage
- ⏱️ Session management dengan idle timeout 30 menit
- 🔄 Routing Lapis 1 (deteksi nama agent di 2 kata pertama)
- 📊 Execution log (audit trail)
- 🌌 Dark mode galaxy theme + visualizer suara
- 📱 Responsive (mobile + desktop)
- 🩺 Halaman debug untuk diagnose masalah

## 📋 Routing Lapis 1

```
User message → cek 2 kata pertama (skip filler) → exact match nama agent?
  ├── YA → Mode BYPASS (kirim langsung ke agent)
  └── TIDAK → Mode DEFAULT (kirim ke orchestrator)
```

Filler yang di-skip: hey, hai, halo, tolong, mohon, please, coba, bisa, bantu, ya, oke

## 🎯 Setup n8n Workflow

Setelah deploy, untuk setiap agent:

1. Buka n8n Anda (https://artha.loophole.site)
2. Buat workflow baru
3. Tambah Webhook trigger node
4. Set:
   - Method: POST
   - Path: agent-{agentId} (mis. agent-mercury, agent-venus)
5. Tambah node AI/LLM sesuai kebutuhan agent
6. Return response JSON: { "reply": "teks respons", "endSession": false }
7. Aktifkan workflow

Untuk orchestrator (Inti Galaksi), path: orchestrator

## 📝 License

Private use.
